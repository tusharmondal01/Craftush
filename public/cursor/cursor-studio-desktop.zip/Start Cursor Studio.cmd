@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if not errorlevel 1 (
  node server.mjs
  goto finished
)
set "CURSOR_STUDIO_NODE=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
if exist "%CURSOR_STUDIO_NODE%" (
  "%CURSOR_STUDIO_NODE%" server.mjs
  goto finished
)
echo Node.js is required to run Cursor Studio.
echo Install the LTS version from https://nodejs.org/ and run this launcher again.
:finished
echo.
pause
