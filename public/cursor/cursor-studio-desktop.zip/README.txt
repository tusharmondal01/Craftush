CURSOR STUDIO
Make your screen a little more cinematic.

START THE STUDIO

1. Extract the entire ZIP to a folder on your computer.
2. Double-click "Start Cursor Studio.cmd".
3. The studio opens at http://127.0.0.1:4173 in your browser.
   Use Chrome or Edge and keep the launcher terminal open while using it.

The launcher needs Node.js installed on your computer or a compatible
bundled Codex runtime. If neither is available, install Node.js and run
the launcher again. You can also run "node server.mjs" from this folder.

TRY IT FIRST

Click "Try a demo" for an eight-second sample with cursor tracking and
automatic zooms. Finish, preview, adjust the style, and export the video.

The package also includes "Examples/phone-demo-raw.mp4": synthetic 9:16
phone footage with no cursor or zooms, supplied for testing Upload footage.

EDIT A PHONE VIDEO

1. Click "Upload footage" or drop a local video into the preview.
   H.264 MP4 is recommended. MOV and WebM work if your browser can decode
   their video and audio. A file's extension alone does not guarantee
   compatibility. No browser extension is needed for imported footage.
2. For a phone recording, choose the 9:16 portrait canvas. At 1080p,
   portrait output is 1080 x 1920 pixels. Your original audio is kept.
3. At full frame (1x), click the detail you want to focus on, then press
   Z to zoom in. Z toggles between full frame and your chosen zoom level:
   2x by default, adjustable from 1x to 5x in the inspector.
4. While zoomed in, click another detail to pan to it. Hold D and drag
   to move the footage. Alternatively, enable "Drag mode" and drag
   without holding a key. Release the drag to save a smooth camera move.
   Turn Drag mode off when you want clicks to select a focus point again.
5. Press Space to play or pause. To edit precisely, pause and move the
   playhead to the moment where a transition should begin, then add or
   change the view. While paused, the preview animates to the destination
   using elapsed real time so you can inspect the move. The saved move
   begins at that playhead position and lasts the configured duration
   (0.8 seconds by default with Silky smooth; Gentle glide takes slightly
   longer). Replay and export use video time to reproduce the same saved
   camera positions.
6. Use "Add focus point" to save the selected focus at your chosen zoom
   setting. In Focus timeline, edit each point's start time, zoom, or
   transition duration ("Ease (s)"), or delete it. Both Motion feel options
   use the same smooth easing; Gentle glide lengthens a new move's duration
   by 1.35 times for a slower pace. Undo reverses the latest camera edit;
   Clear motion removes all camera moves.
7. Click the Z or D shortcut button to assign a different key. Your
   shortcut choices are stored locally on this device. Z and D are the
   defaults. Keep focus on the preview to use shortcuts while editing.
8. Preview the full sequence, then click "Export video". Keep the studio
   tab visible until export finishes. The result is a WebM video with
   the source audio and your saved camera moves, without an added cursor.

These moves are directions you supply while editing. The studio does
not infer taps or cursor positions from an uploaded phone video. Your
editing mouse never appears in the exported phone footage.

RECORD YOUR SCREEN

1. Choose "Screen or window" or "Browser tab" as the recording source.
2. Enable the microphone or system audio if you want sound.
3. Click "Record screen". Your browser shows its actual sharing picker.
   Choose the screen, window, or tab to share, then confirm sharing.
4. Perform your walkthrough. Use Pause if needed, then Finish recording.
5. Preview with the play button and timeline. Adjust the background,
   automatic zoom, cursor, padding, corners, canvas ratio, and quality.
6. Click "Export video" to save a WebM video to your computer.
   Keep the studio tab visible while exporting.

Microphone and screen capture require your permission. System audio
depends on your browser and selected source; enable "Share tab audio"
in the sharing picker when that option is offered.

OPTIONAL: FOLLOW YOUR CURSOR ON OTHER WEBSITES

The companion extension supplies cursor positions and clicks from the
browser tab you share. Install it before starting the recording:

1. Open chrome://extensions or edge://extensions.
2. Turn on Developer mode and click "Load unpacked".
3. Select the included "extension" folder. Alternatively, unzip
   "cursor-studio-extension.zip" and select that extracted folder.
4. Reload the studio and the website tab you want to record.
5. In the studio, choose "Browser tab", click Record screen, and share
   that website tab in the browser's sharing picker.
6. On the shared website tab, click the extension icon and select
   "Track this tab". Pin the extension for easy access if needed.
7. Perform your walkthrough, then return to the studio, finish, style,
   preview, and export your recording.

Automatic follow and click zooms on other websites require the extension
and browser-tab sharing. Screen/window capture can record native apps,
but this version cannot track their cursor globally. Movements inside
embedded iframes or browser toolbars are not tracked.

Some browsers cannot exclude the original cursor from captured video.
If you see two cursors, turn "Show cursor" off in the studio.

WHAT IS INCLUDED

- Screen, window, and browser-tab recording, with supported audio.
- Cursor-follow framing and automatic click zooms with tracking data.
- Four backgrounds, adjustable padding, and rounded corners.
- Widescreen, square, and portrait canvas ratios.
- Playback preview and WebM export at 720p, 1080p, or 1440p.
- Local phone-video import and editable, smooth camera focus points.
- Customizable zoom and drag shortcuts, plus undo and motion reset.
- Editable website source: index.html, styles.css, app.js, camera.js,
  and mobile-editor.js.
- A local server, Windows launcher, and optional browser extension.

YOUR RECORDINGS

No account is needed. Processing stays on your device and recordings
are not uploaded to a cloud service. Recordings are held in memory:
export before closing or reloading the studio, or your recording will
be lost. This package runs locally and does not publish a website.

Export happens in real time. The canvas requests 60 frames per second;
actual frame delivery depends on your browser and hardware, so a fixed
60 fps output is not guaranteed. The browser supplies video decoding:
this package does not include a separate HEVC decoder or an offline,
frame-accurate encoder. If a phone file does not load, convert it to
H.264 MP4 and try again.

WebM is the preferred export format. If a browser cannot encode WebM,
the exporter can use MP4 when that browser offers a compatible encoder.

FOR SOURCE EDITORS

With Node.js installed, run the camera checks from this package folder:

    node --test tests/camera.test.mjs

The package's test shortcut is:

    npm test

RESEARCH.txt explains the camera approach and links its primary sources.
