import http from 'node:http';
import {readFile} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawn} from 'node:child_process';
const root=path.dirname(fileURLToPath(import.meta.url));
const url='http://127.0.0.1:4173/';
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.zip':'application/zip','.txt':'text/plain; charset=utf-8','.json':'application/json','.webm':'video/webm'};
const server=http.createServer(async(req,res)=>{
  if(req.method!=='GET'&&req.method!=='HEAD'){res.writeHead(405);res.end('Method not allowed');return;}
  let filename;
  try {const requestPath=decodeURIComponent(new URL(req.url,url).pathname);filename=path.resolve(root,'.'+(requestPath==='/'?'/index.html':requestPath));}
  catch {res.writeHead(400);res.end('Invalid path');return;}
  const relative=path.relative(root,filename);
  if(relative.startsWith('..')||path.isAbsolute(relative)){res.writeHead(403);res.end('Forbidden');return;}
  try {const body=await readFile(filename);res.writeHead(200,{'Content-Type':types[path.extname(filename)]||'application/octet-stream','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(req.method==='HEAD'?undefined:body);}
  catch {res.writeHead(404);res.end('File not found');}
});
function openBrowser() {
  if(process.argv.includes('--no-open'))return;
  let child;
  if(process.platform==='win32')child=spawn('rundll32.exe',['url.dll,FileProtocolHandler',url],{detached:true,stdio:'ignore',windowsHide:true});
  else child=spawn(process.platform==='darwin'?'open':'xdg-open',[url],{detached:true,stdio:'ignore'});
  child.on('error',()=>console.log(`Open ${url} in Chrome or Edge.`));child.unref();
}
server.on('error',async error=>{
  if(error.code==='EADDRINUSE') {
    try {
      const existing=await fetch(url+'app.js',{signal:AbortSignal.timeout(3000)});
      if(existing.ok && await existing.text()===await readFile(path.join(root,'app.js'),'utf8')) {
        console.log(`Cursor Studio is already running: ${url}`);openBrowser();return;
      }
    }catch{}
    console.error('Port 4173 is already in use. Close the other local server and try again.');
  }else console.error(`Cannot start Cursor Studio: ${error.message}`);
  process.exitCode=1;
});
server.listen(4173,'127.0.0.1',()=>{
  console.log(`\nCursor Studio is ready: ${url}\nKeep this window open while recording. Press Ctrl+C to close.\n`);
  openBrowser();
});
